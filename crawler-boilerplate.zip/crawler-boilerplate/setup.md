
config = {
    "auth": {
        "type": "custom",
        "url": "https://api.example.com/custom-auth",
        "method": "POST",
        "body": {
            "username": "your_username",
            "password": "your_password"
        },
        "token_field": "token",
        "token_type": "Custom",
        "token_path": "data.token",  # For nested token in response
        "cache_key": "custom_auth_token",
        "cache_ttl": 1800  # 30 minutes
    },
    "id": "example_api",
    "name": "Example API",
    "url": "https://api.example.com/data",
    "method": "GET",
    "headers": {
        "Authorization": "Bearer token"
    },
    "pagination": {
        "type": "offset",
        "param_name": "offset",
        "increment_by": 100
    },
    "storage": {
        "table_name": "example_data",
        "schema": {
            "id": "VARCHAR(255)",
            "name": "VARCHAR(255)",
            "created_at": "DATETIME"
        },
        "unique_fields": ["id"],
        "update_fields": ["name", "created_at"]
    },
    "schedule": "*/5 * * * *"  # Every 5 minutes
}

# Add to Redis
redis_client.set(f"api_config:{config['id']}", json.dumps(config))


brew install mysql-connector-c
brew install pkg-config
export LDFLAGS="-L/usr/local/opt/mysql-connector-c/lib"
export CPPFLAGS="-I/usr/local/opt/mysql-connector-c/include"
pip install -r requirements.txt



| Dịch vụ         | Cổng mặc định    | Chức năng                           |
| --------------- | ---------------- | ----------------------------------- |
| Kafka UI        | `localhost:8080` | Xem topic, message, consumer        |
| Flower          | `localhost:5555` | Xem Celery task, trạng thái         |
| Redis Commander | `localhost:8081` | Xem Redis keys, config              |
| phpMyAdmin      | `localhost:8082` | Truy cập MySQL UI                   |
| Kibana          | `localhost:5601` | Xem dữ liệu Log (nếu push logstash) |
| Portainer       | `localhost:9000` | Quản lý container, logs             |
