# Flexible API Crawler System

A configurable and scalable API crawling system that supports dynamic configuration, parallel processing, pagination, retry mechanisms, rate limiting, and flexible data storage.

## Features

- Dynamic configuration-driven architecture
- No code changes required for new APIs
- Parallel processing with Celery workers
- Kafka-based message queue
- Flexible data storage in MySQL
- Rate limiting and retry mechanisms
- Docker-based deployment
- Comprehensive logging and monitoring

## Project Structure

```
.
├── docker-compose.yml
├── requirements.txt
├── src/
│   ├── config/
│   │   ├── __init__.py
│   │   ├── settings.py
│   │   └── models.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── crawler.py
│   │   ├── processor.py
│   │   └── validator.py
│   ├── workers/
│   │   ├── __init__.py
│   │   └── tasks.py
│   ├── scheduler/
│   │   ├── __init__.py
│   │   └── scheduler.py
│   └── utils/
│       ├── __init__.py
│       ├── rate_limiter.py
│       └── logger.py
└── tests/
    └── __init__.py
```

## Setup and Installation

1. Clone the repository
2. Create a `.env` file with your configuration
3. Run with Docker Compose:
   ```bash
   docker-compose up -d
   ```

## Configuration

The system uses Redis/MySQL to store API configurations. Each API configuration includes:
- URL and method
- Headers and query parameters
- Rate limiting rules
- Pagination settings
- Timeout settings
- Data storage configuration

## Usage

1. Add new API configurations to Redis/MySQL
2. The scheduler will automatically pick up new configurations
3. Workers process the crawl jobs
4. Results are stored in MySQL

## Development

To run the project locally:

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Start the required services:
   ```bash
   docker-compose up -d redis kafka mysql
   ```

3. Run the scheduler:
   ```bash
   python src/scheduler/scheduler.py
   ```

4. Run the worker:
   ```bash
   celery -A src.workers.tasks worker --loglevel=info
   ``` 

Hỗ trợ nhiều loại authentication:
Basic Auth
Bearer Token
OAuth2
API Key
Custom Authentication
Token Caching:
Tự động cache token
Hỗ trợ token expiration
Tái sử dụng token cho đến khi hết hạn
Linh hoạt trong cấu hình:
Có thể cấu hình URL, method, headers, body
Hỗ trợ nested token trong response
Tùy chỉnh token type và field names
Tự động refresh:
Tự động lấy token mới khi token hết hạn
Xử lý lỗi và retry
Tích hợp với rate limiting:
Authentication requests cũng được rate limit
Tránh quá tải authentication server