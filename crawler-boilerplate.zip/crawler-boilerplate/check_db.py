from sqlalchemy import create_engine, text

# Create engine
engine = create_engine('mysql://appuser:Admin123$@10.14.119.8:3306/crawler')

# Check tables
with engine.connect() as conn:
    result = conn.execute(text('SHOW TABLES'))
    print('Tables:', [row[0] for row in result]) 