from sqlalchemy import create_engine, text

# Create engine
engine = create_engine('mysql://appuser:Admin123$@10.14.119.8:3306/crawler')

# Check data
with engine.connect() as conn:
    result = conn.execute(text('SELECT COUNT(*) as count FROM irbm_documents'))
    count = result.fetchone()[0]
    print('Total records:', count)
    
    if count > 0:
        result = conn.execute(text('SELECT * FROM irbm_documents LIMIT 1'))
        row = result.fetchone()
        print('\nSample record:')
        for key, value in row._mapping.items():
            print(f"{key}: {value}") 