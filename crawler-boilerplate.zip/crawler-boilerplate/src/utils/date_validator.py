import datetime
from typing import Tuple
from datetime import datetime, timedelta

def validate_and_adjust_date_range(from_date: str, to_date: str) -> Tuple[str, str]:
    """
    Validate and adjust the date range to ensure it's within 31 days.
    
    Args:
        from_date (str): Start date in YYYY-MM-DD format
        to_date (str): End date in YYYY-MM-DD format
        
    Returns:
        Tuple[str, str]: Adjusted from_date and to_date
    """
    # Parse dates
    from_dt = datetime.strptime(from_date, "%Y-%m-%d")
    to_dt = datetime.strptime(to_date, "%Y-%m-%d")
    
    # Calculate date difference
    date_diff = (to_dt - from_dt).days
    
    # If date range is more than 31 days, adjust from_date
    if date_diff > 31:
        from_dt = to_dt - timedelta(days=31)
        from_date = from_dt.strftime("%Y-%m-%d")
    
    # If to_date is in the future, set it to today
    today = datetime.now().date()
    if to_dt.date() > today:
        to_date = today.strftime("%Y-%m-%d")
        # Recalculate from_date to maintain 31 days range
        from_dt = datetime.strptime(to_date, "%Y-%m-%d") - timedelta(days=31)
        from_date = from_dt.strftime("%Y-%m-%d")
    
    return from_date, to_date

def get_date_range() -> Tuple[str, str]:
    """
    Get the current date range for crawling.
    Returns a tuple of (from_date, to_date) where the range is 31 days.
    """
    to_date = datetime.now().date()
    from_date = to_date - timedelta(days=31)
    
    return from_date.strftime("%Y-%m-%d"), to_date.strftime("%Y-%m-%d") 