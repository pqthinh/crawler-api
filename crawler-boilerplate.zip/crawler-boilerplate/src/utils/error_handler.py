from enum import Enum
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import re
from src.utils.logger import setup_logger

logger = setup_logger(__name__)

class ErrorType(Enum):
    IP_BLOCK = "ip_block"
    ACCOUNT_SUSPENDED = "account_suspended"
    RATE_LIMIT = "rate_limit"
    OTHER = "other"

class ErrorHandler:
    def __init__(self):
        self.ip_block_patterns = [
            r"IP.*blocked",
            r"IP.*banned",
            r"Too many requests",
            r"Access denied",
            r"403 Forbidden",
            r"429 Too Many Requests"
        ]
        
        self.account_suspend_patterns = [
            r"account.*suspended",
            r"account.*locked",
            r"account.*disabled",
            r"invalid.*credentials",
            r"unauthorized",
            r"401 Unauthorized"
        ]

    def analyze_error(self, error: str, status_code: Optional[int] = None) -> Dict[str, Any]:
        """Analyze error and determine its type and required action."""
        error = error.lower()
        
        # Check for IP block patterns
        for pattern in self.ip_block_patterns:
            if re.search(pattern, error, re.IGNORECASE):
                return {
                    "type": ErrorType.IP_BLOCK,
                    "action": "wait",
                    "wait_time": 3600,  # 1 hour
                    "message": "IP address has been blocked"
                }
        
        # Check for account suspension patterns
        for pattern in self.account_suspend_patterns:
            if re.search(pattern, error, re.IGNORECASE):
                return {
                    "type": ErrorType.ACCOUNT_SUSPENDED,
                    "action": "wait",
                    "wait_time": 86400,  # 24 hours
                    "message": "Account has been suspended"
                }
        
        # Check status codes
        if status_code == 429:
            return {
                "type": ErrorType.RATE_LIMIT,
                "action": "wait",
                "wait_time": 600,  # 10 minutes
                "message": "Rate limit exceeded"
            }
        
        return {
            "type": ErrorType.OTHER,
            "action": "retry",
            "wait_time": 60,  # 1 minute
            "message": "Unknown error"
        }

    def get_wait_time(self, error_type: ErrorType, retry_count: int) -> int:
        """Calculate wait time based on error type and retry count."""
        base_times = {
            ErrorType.IP_BLOCK: 3600,  # 1 hour
            ErrorType.ACCOUNT_SUSPENDED: 86400,  # 24 hours
            ErrorType.RATE_LIMIT: 600,  # 10 minutes
            ErrorType.OTHER: 60  # 1 minute
        }
        
        # Exponential backoff
        return base_times[error_type] * (2 ** min(retry_count, 3))

    def should_retry(self, error_type: ErrorType, retry_count: int) -> bool:
        """Determine if the job should be retried based on error type and retry count."""
        max_retries = {
            ErrorType.IP_BLOCK: 3,
            ErrorType.ACCOUNT_SUSPENDED: 2,
            ErrorType.RATE_LIMIT: 5,
            ErrorType.OTHER: 3
        }
        
        return retry_count < max_retries[error_type] 