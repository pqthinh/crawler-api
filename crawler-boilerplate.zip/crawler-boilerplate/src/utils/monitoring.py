import json
import time
import logging
import socket
from datetime import datetime
from typing import Dict, Any, Optional
from elasticsearch import Elasticsearch
from src.utils.logger import setup_logger

logger = setup_logger(__name__)

class JobMonitor:
    def __init__(self, es_host: str = "elasticsearch", es_port: int = 9200):
        self.es = Elasticsearch([f"http://{es_host}:{es_port}"])
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect(('logstash', 5000))

    def _send_to_logstash(self, data: Dict[str, Any]):
        """Send data to Logstash."""
        try:
            self.socket.sendall((json.dumps(data) + '\n').encode())
        except Exception as e:
            logger.error(f"Error sending data to Logstash: {str(e)}")

    def log_job_start(self, job_id: str, api_id: str, config: Dict[str, Any]):
        """Log job start."""
        data = {
            "type": "crawl_job",
            "timestamp": datetime.utcnow().isoformat(),
            "job_id": job_id,
            "api_id": api_id,
            "status": "started",
            "config": config
        }
        self._send_to_logstash(data)

    def log_job_success(self, job_id: str, api_id: str, stats: Dict[str, Any]):
        """Log job success."""
        data = {
            "type": "crawl_job",
            "timestamp": datetime.utcnow().isoformat(),
            "job_id": job_id,
            "api_id": api_id,
            "status": "success",
            "stats": stats
        }
        self._send_to_logstash(data)

    def log_job_error(self, job_id: str, api_id: str, error: str, 
                     retry_count: int = 0, will_retry: bool = False):
        """Log job error."""
        data = {
            "type": "crawl_error",
            "timestamp": datetime.utcnow().isoformat(),
            "job_id": job_id,
            "api_id": api_id,
            "error": error,
            "retry_count": retry_count,
            "will_retry": will_retry
        }
        self._send_to_logstash(data)

    def log_request_error(self, job_id: str, api_id: str, url: str, 
                         status_code: Optional[int], error: str,
                         retry_count: int = 0):
        """Log individual request error."""
        data = {
            "type": "crawl_error",
            "timestamp": datetime.utcnow().isoformat(),
            "job_id": job_id,
            "api_id": api_id,
            "url": url,
            "status_code": status_code,
            "error": error,
            "retry_count": retry_count,
            "error_type": "request_error"
        }
        self._send_to_logstash(data)

    def get_job_status(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Get job status from Elasticsearch."""
        try:
            result = self.es.search(
                index="crawl-jobs-*",
                body={
                    "query": {
                        "term": {
                            "job_id": job_id
                        }
                    },
                    "sort": [
                        {"timestamp": "desc"}
                    ],
                    "size": 1
                }
            )
            
            if result["hits"]["total"]["value"] > 0:
                return result["hits"]["hits"][0]["_source"]
            return None
            
        except Exception as e:
            logger.error(f"Error getting job status: {str(e)}")
            return None

    def get_failed_jobs(self, api_id: Optional[str] = None, 
                       start_time: Optional[str] = None,
                       end_time: Optional[str] = None) -> list:
        """Get list of failed jobs."""
        try:
            query = {
                "bool": {
                    "must": [
                        {"term": {"status": "error"}}
                    ]
                }
            }
            
            if api_id:
                query["bool"]["must"].append({"term": {"api_id": api_id}})
                
            if start_time or end_time:
                range_query = {"range": {"timestamp": {}}}
                if start_time:
                    range_query["range"]["timestamp"]["gte"] = start_time
                if end_time:
                    range_query["range"]["timestamp"]["lte"] = end_time
                query["bool"]["must"].append(range_query)
            
            result = self.es.search(
                index="crawl-jobs-*",
                body={
                    "query": query,
                    "sort": [
                        {"timestamp": "desc"}
                    ],
                    "size": 100
                }
            )
            
            return [hit["_source"] for hit in result["hits"]["hits"]]
            
        except Exception as e:
            logger.error(f"Error getting failed jobs: {str(e)}")
            return []

    def get_error_stats(self, api_id: Optional[str] = None,
                       start_time: Optional[str] = None,
                       end_time: Optional[str] = None) -> Dict[str, Any]:
        """Get error statistics."""
        try:
            query = {
                "bool": {
                    "must": [
                        {"term": {"type": "crawl_error"}}
                    ]
                }
            }
            
            if api_id:
                query["bool"]["must"].append({"term": {"api_id": api_id}})
                
            if start_time or end_time:
                range_query = {"range": {"timestamp": {}}}
                if start_time:
                    range_query["range"]["timestamp"]["gte"] = start_time
                if end_time:
                    range_query["range"]["timestamp"]["lte"] = end_time
                query["bool"]["must"].append(range_query)
            
            result = self.es.search(
                index="crawl-errors-*",
                body={
                    "query": query,
                    "aggs": {
                        "error_types": {
                            "terms": {
                                "field": "error_type.keyword",
                                "size": 10
                            }
                        },
                        "by_api": {
                            "terms": {
                                "field": "api_id.keyword",
                                "size": 10
                            }
                        },
                        "retry_stats": {
                            "stats": {
                                "field": "retry_count"
                            }
                        }
                    },
                    "size": 0
                }
            )
            
            return {
                "error_types": result["aggregations"]["error_types"]["buckets"],
                "by_api": result["aggregations"]["by_api"]["buckets"],
                "retry_stats": result["aggregations"]["retry_stats"]
            }
            
        except Exception as e:
            logger.error(f"Error getting error stats: {str(e)}")
            return {} 