import time
from threading import Lock
from typing import Optional

class RateLimiter:
    def __init__(self, requests_per_second: float, burst_size: int):
        self.rate = requests_per_second
        self.burst_size = burst_size
        self.tokens = burst_size
        self.last_update = time.time()
        self.lock = Lock()

    def _update_tokens(self):
        """Update the token count based on time elapsed."""
        now = time.time()
        time_passed = now - self.last_update
        self.tokens = min(
            self.burst_size,
            self.tokens + time_passed * self.rate
        )
        self.last_update = now

    def acquire(self) -> bool:
        """Try to acquire a token."""
        with self.lock:
            self._update_tokens()
            if self.tokens >= 1:
                self.tokens -= 1
                return True
            return False

    def __enter__(self):
        """Context manager entry."""
        while not self.acquire():
            time.sleep(0.1)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        pass 