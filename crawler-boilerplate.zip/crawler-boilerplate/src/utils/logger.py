import logging
import sys
from pythonjsonlogger import jsonlogger

def setup_logger(name: str = None) -> logging.Logger:
    """Setup a JSON logger with consistent formatting."""
    logger = logging.getLogger(name or __name__)
    
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        
        # Create console handler
        handler = logging.StreamHandler(sys.stdout)
        
        # Create JSON formatter
        formatter = jsonlogger.JsonFormatter(
            '%(asctime)s %(name)s %(levelname)s %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # Set formatter and add handler
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    
    return logger 