from datetime import datetime, timedelta
from typing import Generator, Tuple

class DateRangeIterator:
    def __init__(self, start_date: str, end_date: str = None):
        """
        Initialize date range iterator.
        
        Args:
            start_date (str): Start date in YYYY-MM-DD format
            end_date (str): End date in YYYY-MM-DD format, defaults to today
        """
        self.start_date = datetime.strptime(start_date, "%Y-%m-%d")
        if end_date is None or end_date == "now":
            self.end_date = datetime.now()
        else:
            self.end_date = datetime.strptime(end_date, "%Y-%m-%d")
            if self.end_date > datetime.now():
                self.end_date = datetime.now()

    def get_ranges(self) -> Generator[Tuple[str, str], None, None]:
        """
        Generate date ranges in 31-day chunks.
        
        Yields:
            Tuple[str, str]: A tuple of (from_date, to_date) in YYYY-MM-DD format
        """
        current_start = self.start_date
        
        while current_start < self.end_date:
            # Calculate end of current chunk
            current_end = min(
                current_start + timedelta(days=30),  # 31 days including start date
                self.end_date
            )
            
            yield (
                current_start.strftime("%Y-%m-%d"),
                current_end.strftime("%Y-%m-%d")
            )
            
            # Move to next chunk
            current_start = current_end + timedelta(days=1)

    def get_total_days(self) -> int:
        """Get total number of days to process."""
        return (self.end_date - self.start_date).days + 1

    def get_chunk_count(self) -> int:
        """Get total number of 31-day chunks."""
        total_days = self.get_total_days()
        return (total_days + 30) // 31  # Round up division 