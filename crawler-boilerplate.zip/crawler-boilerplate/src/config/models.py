from typing import Dict, List, Optional, Union, Any
from pydantic import BaseModel, HttpUrl, Field
from enum import Enum
from src.core.auth import AuthType, AuthConfig

class HttpMethod(str, Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"

class PaginationType(str, Enum):
    NONE = "none"
    CURSOR = "cursor"
    OFFSET = "offset"
    PAGE = "page"

class RateLimitConfig(BaseModel):
    requests_per_second: float = 1.0
    burst_size: int = 10
    retry_after: int = 60  # seconds

class PaginationConfig(BaseModel):
    type: PaginationType
    param_name: Optional[str] = None
    start_value: Union[int, str] = 0
    increment_by: Optional[int] = None
    cursor_field: Optional[str] = None
    has_more_field: Optional[str] = None
    data_field: Optional[str] = None
    total_pages_field: Optional[str] = None
    total_count_field: Optional[str] = None
    items_per_page: Optional[int] = None

class StorageConfig(BaseModel):
    table_name: str
    table_schema: Dict[str, str]  # field_name: data_type
    unique_fields: List[str] = []
    update_fields: List[str] = []
    field_mapping: Optional[Dict[str, str]] = None  # db_field: response_field

class Variable(BaseModel):
    type: str
    format: Optional[str] = None
    value: Optional[str] = None

class APIConfig(BaseModel):
    id: str
    name: str
    url: HttpUrl
    method: HttpMethod = HttpMethod.GET
    headers: Dict[str, str] = {}
    query_params: Dict[str, str] = {}
    body: Optional[Dict] = None
    timeout: int = 30
    rate_limit: RateLimitConfig = RateLimitConfig()
    pagination: PaginationConfig
    storage: StorageConfig
    schedule: str  # cron expression
    enabled: bool = True
    auth: Optional[AuthConfig] = None  # Authentication configuration
    retry_config: Dict[str, int] = Field(
        default_factory=lambda: {
            "max_retries": 3,
            "initial_delay": 1,
            "max_delay": 60,
            "backoff_factor": 2
        }
    )
    variables: Optional[Dict[str, Variable]] = None

    class Config:
        arbitrary_types_allowed = True

    def get_processed_params(self, variables: Dict[str, Any]) -> Dict[str, Any]:
        """Get query parameters with variables replaced."""
        processed = {}
        for key, value in self.query_params.items():
            if isinstance(value, str) and value.startswith('{') and value.endswith('}'):
                var_name = value[1:-1]
                if var_name in variables:
                    processed[key] = variables[var_name]
            else:
                processed[key] = value
        return processed 