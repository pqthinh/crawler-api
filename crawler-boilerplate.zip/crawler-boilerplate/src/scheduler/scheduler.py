import json
import time
import logging
from typing import Dict, Any
import redis
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from src.config.models import APIConfig
from src.workers.tasks import process_api_crawl
from src.utils.logger import setup_logger
import os
import uuid

logger = setup_logger()

class CrawlerScheduler:
    def __init__(self):
        # Read Redis config from environment variables
        redis_host = os.getenv('REDIS_HOST', '10.14.119.8') # Default to your host
        redis_port = int(os.getenv('REDIS_PORT', 6379))
        redis_db = int(os.getenv('REDIS_DB', 0))
        redis_password = os.getenv('REDIS_PASSWORD', 'redis@6379') # Default to your password

        self.redis_client = redis.Redis(
            host=redis_host,
            port=redis_port,
            db=redis_db,
            password=redis_password if redis_password else None,
            decode_responses=True
        )
        self.scheduler = BackgroundScheduler()
        self.configs: Dict[str, APIConfig] = {}

    def load_configs(self):
        """Load API configurations from Redis."""
        try:
            # Get all API configs from Redis
            config_keys = self.redis_client.keys('api_config:*')
            
            for key in config_keys:
                config_data = self.redis_client.get(key)
                if config_data:
                    try:
                        config = APIConfig(**json.loads(config_data))
                        self.configs[config.id] = config
                        logger.info(f"Loaded configuration for API {config.id}")
                    except Exception as e:
                        logger.error(f"Error loading config {key}: {str(e)}")
                        
        except Exception as e:
            logger.error(f"Error loading configurations: {str(e)}")

    def schedule_job(self, config: APIConfig):
        """Schedule a single API crawl job."""
        if not config.enabled:
            return

        def job_function():
            try:
                # Generate a unique job ID
                job_id = str(uuid.uuid4())
                # Send task to Celery with all required args
                process_api_crawl.delay(
                    job_id=job_id, 
                    api_id=config.id, 
                    config_dict=config.model_dump(mode='json') # Use mode='json'
                )
                logger.info(f"Scheduled crawl job {job_id} for API {config.id}")
            except Exception as e:
                logger.error(f"Error scheduling job for API {config.id}: {str(e)}")

        # Add job to scheduler
        self.scheduler.add_job(
            job_function,
            CronTrigger.from_crontab(config.schedule),
            id=f"crawl_{config.id}",
            replace_existing=True
        )

    def start(self):
        """Start the scheduler."""
        try:
            # Load initial configurations
            self.load_configs()
            
            # Schedule all jobs
            for config in self.configs.values():
                self.schedule_job(config)
            
            # Start the scheduler
            self.scheduler.start()
            logger.info("Scheduler started successfully")
            
            # Keep the main thread alive
            try:
                while True:
                    time.sleep(1)
            except (KeyboardInterrupt, SystemExit):
                self.scheduler.shutdown()
                
        except Exception as e:
            logger.error(f"Error starting scheduler: {str(e)}")
            raise

if __name__ == "__main__":
    scheduler = CrawlerScheduler()
    scheduler.start() 