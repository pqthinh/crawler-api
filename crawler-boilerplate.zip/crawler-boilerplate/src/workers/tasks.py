import json
import logging
import uuid
from typing import Dict, Any
from celery import Celery
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from src.core.crawler import APICrawler
from src.config.models import APIConfig
from src.utils.logger import setup_logger
from src.utils.monitoring import JobMonitor
from src.utils.error_handler import ErrorHandler, ErrorType
import time
import redis
import os

# Setup logging
logger = setup_logger()

# Initialize Celery
celery = Celery('crawler_tasks', broker='kafka://kafka:29092')

# Database setup
engine = create_engine('mysql://crawler:crawlerpass@mysql/crawler')
Session = sessionmaker(bind=engine)

# Redis Client Setup (read config from environment or defaults)
redis_host = os.getenv('REDIS_HOST', '10.14.119.8') # Default to your host
redis_port = int(os.getenv('REDIS_PORT', 6379))
redis_db = int(os.getenv('REDIS_DB', 0))
redis_password = os.getenv('REDIS_PASSWORD', 'redis@6379') # Default to your password
# Assuming no password based on scheduler setup, add if needed
redis_client = redis.Redis(
    host=redis_host, 
    port=redis_port, 
    db=redis_db, 
    password=redis_password if redis_password else None, 
    decode_responses=True
)

# Initialize job monitor and error handler
job_monitor = JobMonitor()
error_handler = ErrorHandler()

@celery.task(bind=True, max_retries=5)
def process_api_crawl(self, job_id: str, api_id: str, config_dict: Dict[str, Any]):
    """Process API crawl job."""
    lock_key = f"api_crawl_lock:{api_id}"
    lock_timeout = 3600  # Lock expires after 1 hour (adjust as needed)

    # Try to acquire the lock
    is_lock_acquired = redis_client.set(lock_key, job_id, nx=True, ex=lock_timeout)

    if not is_lock_acquired:
        logger.warning(f"Skipping job {job_id} for API {api_id}: Previous job may still be running.")
        return  # Exit if lock not acquired

    try:
        # Reconstruct APIConfig model from the dictionary
        try:
            api_config = APIConfig(**config_dict)
        except Exception as validation_error:
             logger.error(f"Failed to validate config for job {job_id}, API {api_id}: {validation_error}")
             # Optionally: delete lock if config is invalid?
             # redis_client.delete(lock_key)
             raise # Re-raise validation error to stop processing

        # Log job start
        job_monitor.log_job_start(job_id, api_id, config_dict) # Log original dict
        
        # Initialize crawler with the Pydantic model instance
        crawler = APICrawler(api_config, redis_client, api_id)
        
        # Process data
        stats = {
            "processed": 0,
            "updated": 0,
            "inserted": 0,
            "errors": 0
        }
        
        for item in crawler.crawl():
            try:
                # Process item
                stats["processed"] += 1
                # Prepare the data for storage
                table_name = config_dict.get('storage', {}).get('table_name', 'unknown')
                fields = list(config_dict.get('storage', {}).get('table_schema', {}).keys())
                
                # Create the insert/update statement
                stmt = text(f"""
                    INSERT INTO {table_name} ({', '.join(fields)})
                    VALUES ({', '.join([f':{field}' for field in fields])})
                    ON DUPLICATE KEY UPDATE
                    {', '.join([f"{field} = VALUES({field})" 
                              for field in config_dict.get('storage', {}).get('update_fields', [])])}
                """)
                
                # Execute the statement
                session = Session()
                result = session.execute(stmt, item)
                session.commit()
                
                # Update stats
                if result.rowcount > 0:
                    stats["inserted"] += 1
                else:
                    stats["updated"] += 1
                
            except Exception as e:
                stats["errors"] += 1
                error_info = error_handler.analyze_error(str(e))
                
                # Log error with detailed information
                job_monitor.log_job_error(
                    job_id=job_id,
                    api_id=api_id,
                    error=str(e),
                    retry_count=self.request.retries,
                    will_retry=error_handler.should_retry(error_info["type"], self.request.retries)
                )
                
                # Handle different error types
                if error_info["type"] in [ErrorType.IP_BLOCK, ErrorType.ACCOUNT_SUSPENDED]:
                    # For IP blocks and account suspensions, wait longer
                    wait_time = error_handler.get_wait_time(error_info["type"], self.request.retries)
                    if error_handler.should_retry(error_info["type"], self.request.retries):
                        raise self.retry(exc=e, countdown=wait_time)
                    else:
                        # If max retries reached, log final error and stop
                        job_monitor.log_job_error(
                            job_id=job_id,
                            api_id=api_id,
                            error=f"Max retries reached for {error_info['type'].value}: {str(e)}",
                            retry_count=self.request.retries,
                            will_retry=False
                        )
                        break
                else:
                    # For other errors, use normal retry logic
                    if error_handler.should_retry(error_info["type"], self.request.retries):
                        raise self.retry(exc=e, countdown=error_info["wait_time"])
        
        # Log success
        job_monitor.log_job_success(job_id, api_id, stats)
        
    except Exception as e:
        error_info = error_handler.analyze_error(str(e))
        
        # Log error
        job_monitor.log_job_error(
            job_id=job_id,
            api_id=api_id,
            error=str(e),
            retry_count=self.request.retries,
            will_retry=error_handler.should_retry(error_info["type"], self.request.retries)
        )
        
        # Handle retry based on error type
        if error_handler.should_retry(error_info["type"], self.request.retries):
            wait_time = error_handler.get_wait_time(error_info["type"], self.request.retries)
            raise self.retry(exc=e, countdown=wait_time)
        else:
            # If max retries reached, log final error
            job_monitor.log_job_error(
                job_id=job_id,
                api_id=api_id,
                error=f"Max retries reached for {error_info['type'].value}: {str(e)}",
                retry_count=self.request.retries,
                will_retry=False
            )
            raise 
    finally:
        # Ensure the lock is released
        if is_lock_acquired:
            redis_client.delete(lock_key)
            logger.info(f"Released lock {lock_key} for job {job_id}") 