import json
import logging
from typing import Dict, Any, Optional, Generator
import requests
from urllib.parse import parse_qs, urlparse
from tenacity import retry, stop_after_attempt, wait_exponential
from src.config.models import APIConfig, PaginationType
from src.utils.rate_limiter import RateLimiter
from src.core.auth import AuthHandler
from src.core.config import ConfigHandler
from src.utils.date_range_iterator import DateRangeIterator
from redis import Redis
from datetime import datetime

logger = logging.getLogger(__name__)

class APICrawler:
    def __init__(self, config: APIConfig, redis_client: Redis, api_id: str):
        self.config = config
        self.api_id = api_id
        self.redis_client = redis_client
        self.checkpoint_key = f"api_crawl_checkpoint:{self.api_id}"
        self.rate_limiter = RateLimiter(
            requests_per_second=config.rate_limit.requests_per_second,
            burst_size=config.rate_limit.burst_size
        )
        self.session = requests.Session()
        if config.headers:
            self.session.headers.update(config.headers)
        
        self.auth_handler = None
        if config.auth:
            self.auth_handler = AuthHandler(config.auth)
            
        # Initialize config handler for variable processing
        self.config_handler = ConfigHandler()
        self._initialize_variables()

    def _initialize_variables(self):
        """Initialize variables including dates."""
        from src.utils.date_validator import get_date_range
        from_date, to_date = get_date_range()
        
        # Store initial variables
        self.config_handler.variables.update({
            'page': 1,
            'from_date': from_date,
            'to_date': to_date
        })

    def _get_request_params(self, current_value: Any = None) -> Dict[str, Any]:
        """Get request parameters with variables replaced."""
        # Update page number in variables if provided
        if current_value is not None:
            self.config_handler.update_variable('page', current_value)
        
        # Get processed parameters using config handler's variables
        params = self.config.get_processed_params(self.config_handler.variables)
        
        logger.debug(f"Processed parameters with variables: {params}")
        return params

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=10),
        reraise=True
    )
    def _make_request(self, params: Optional[Dict[str, Any]] = None) -> requests.Response:
        """Make a rate-limited HTTP request with retry logic."""
        with self.rate_limiter:
            auth_headers = {}
            if self.auth_handler:
                auth_headers = self.auth_handler.get_auth_headers()
            
            if auth_headers:
                self.session.headers.update(auth_headers)
            
            request_params = self._get_request_params() if params is None else params
            logger.info(f"Making request: {self.config.method} {self.config.url} PARAMS: {request_params}")
            
            response = self.session.request(
                method=self.config.method,
                url=str(self.config.url),
                params=request_params,
                json=self.config.body,
                timeout=self.config.timeout
            )
            logger.info(f"Received response: Status {response.status_code} for {self.config.url}")
            response.raise_for_status()
            return response

    def _get_pagination_params(self, current_value: Any) -> Dict[str, Any]:
        """Generate pagination parameters based on the current value."""
        return self._get_request_params(current_value)

    def _extract_data(self, response: requests.Response) -> Dict[str, Any]:
        """Extract data from the response based on configuration."""
        data = response.json()
        if self.config.pagination.data_field:
            data = data.get(self.config.pagination.data_field, data)
        return data

    def _get_next_value(self, response: requests.Response) -> Optional[Any]:
        """Get the next pagination value based on the response."""
        if self.config.pagination.type == PaginationType.NONE:
            return None

        data = response.json()
        
        if self.config.pagination.type == PaginationType.CURSOR:
            return data.get(self.config.pagination.cursor_field)
        
        elif self.config.pagination.type == PaginationType.OFFSET:
            # Parse the current offset from URL parameters
            parsed_url = urlparse(response.request.url)
            params = parse_qs(parsed_url.query)
            current = int(params.get(self.config.pagination.param_name, [0])[0])
            return current + (self.config.pagination.increment_by or 1)
        
        elif self.config.pagination.type == PaginationType.PAGE:
            # Parse the current page from URL parameters
            parsed_url = urlparse(response.request.url)
            params = parse_qs(parsed_url.query)
            current = int(params.get(self.config.pagination.param_name, [1])[0])
            
            # Check if we've reached the total pages
            if self.config.pagination.total_pages_field:
                total_pages = data
                for field in self.config.pagination.total_pages_field.split('.'):
                    total_pages = total_pages.get(field, {})
                if isinstance(total_pages, (int, str)) and current >= int(total_pages):
                    return None
            
            return current + 1

        return None

    def _has_more_data(self, response: requests.Response) -> bool:
        """Check if there is more data to fetch."""
        if self.config.pagination.type == PaginationType.NONE:
            return False

        data = response.json()
        
        # Check has_more_field if specified
        if self.config.pagination.has_more_field:
            current = data
            for field in self.config.pagination.has_more_field.split('.'):
                current = current.get(field, {})
            return bool(current)
        
        # For page-based pagination, check against total pages
        elif self.config.pagination.type == PaginationType.PAGE and self.config.pagination.total_pages_field:
            parsed_url = urlparse(response.request.url)
            params = parse_qs(parsed_url.query)
            current_page = int(params.get(self.config.pagination.param_name, [1])[0])
            
            total_pages = data
            for field in self.config.pagination.total_pages_field.split('.'):
                total_pages = total_pages.get(field, {})
            
            if isinstance(total_pages, (int, str)):
                return current_page < int(total_pages)
        
        # For cursor-based pagination, check if next cursor exists
        elif self.config.pagination.type == PaginationType.CURSOR and self.config.pagination.cursor_field:
            next_cursor = data.get(self.config.pagination.cursor_field)
            return bool(next_cursor)
        
        # Default to checking if there's data in the response
        return bool(self._extract_data(response))

    def crawl_historical(self, start_date: str, end_date: str = None) -> Generator[Dict[str, Any], None, None]:
        """
        Crawl historical data between start_date and end_date in 31-day chunks.
        
        Args:
            start_date (str): Start date in YYYY-MM-DD format
            end_date (str): End date in YYYY-MM-DD format, defaults to today
        """
        date_iterator = DateRangeIterator(start_date, end_date)
        total_chunks = date_iterator.get_chunk_count()
        current_chunk = 1
        
        for from_date, to_date in date_iterator.get_ranges():
            logger.info(f"Processing historical data chunk {current_chunk}/{total_chunks} "
                       f"from {from_date} to {to_date}")
            
            # Update date variables
            self.config_handler.update_variable('from_date', from_date)
            self.config_handler.update_variable('to_date', to_date)
            
            # Reset page number for each date range
            self.config_handler.update_variable('page', 1)
            
            try:
                # Process this date range
                for item in self.crawl():
                    yield item
                    
                logger.info(f"Completed chunk {current_chunk}/{total_chunks}")
                current_chunk += 1
                
            except Exception as e:
                logger.error(f"Error processing date range {from_date} to {to_date}: {str(e)}")
                raise

    def crawl(self) -> Generator[Dict[str, Any], None, None]:
        """Crawl the API and yield data items, handling checkpoints."""
        # Read start value from checkpoint or config
        start_value = self.redis_client.get(self.checkpoint_key)
        if start_value:
            logger.info(f"Resuming crawl for API {self.api_id} from checkpoint: {start_value}")
            try:
                current_value = int(start_value) if self.config.pagination.type in [PaginationType.OFFSET, PaginationType.PAGE] else start_value
            except ValueError:
                logger.error(f"Invalid checkpoint value for {self.api_id}: {start_value}. Starting from beginning.")
                current_value = self.config.pagination.start_value
        else:
            logger.info(f"Starting crawl for API {self.api_id} from beginning.")
            current_value = self.config.pagination.start_value
        
        crawl_completed_successfully = False
        try:
            while True:
                try:
                    params = self._get_pagination_params(current_value)
                    response = self._make_request(params)
                    data = self._extract_data(response)
                    
                    # Determine the next value before processing
                    next_value = self._get_next_value(response)
                    has_more = self._has_more_data(response)
                    
                    # Process and yield data
                    if isinstance(data, list):
                        if not data:
                            logger.info(f"Received empty data list for API {self.api_id} at value {current_value}")
                        for item in data:
                            yield item
                    elif data:
                        yield data
                    else:
                        logger.info(f"Received empty data for API {self.api_id} at value {current_value}")
                    
                    if not has_more or next_value is None:
                        crawl_completed_successfully = True
                        break
                    
                    # Update checkpoint and continue
                    self.redis_client.set(self.checkpoint_key, str(next_value))
                    logger.debug(f"Updated checkpoint for API {self.api_id} to: {next_value}")
                    current_value = next_value
                    
                except requests.exceptions.RequestException as e:
                    logger.error(f"Request error during crawl for API {self.api_id} at value {current_value}: {str(e)}")
                    raise
                except Exception as e:
                    logger.error(f"Unexpected error during crawl for API {self.api_id} at value {current_value}: {str(e)}")
                    raise
        finally:
            if crawl_completed_successfully:
                logger.info(f"Crawl completed successfully for API {self.api_id}. Clearing checkpoint.")
                self.redis_client.delete(self.checkpoint_key) 