from datetime import datetime
from typing import Dict, Any
from ..utils.date_validator import validate_and_adjust_date_range, get_date_range

class ConfigHandler:
    def __init__(self):
        self.variables: Dict[str, Any] = {}
        self._initialize_variables()

    def _initialize_variables(self):
        """Initialize default variables."""
        from_date, to_date = get_date_range()
        self.variables.update({
            'page': 1,
            'from_date': from_date,
            'to_date': to_date
        })

    def process_variables(self, config: dict) -> dict:
        """Process and validate configuration variables."""
        if 'variables' in config:
            # Update query params with actual values
            if 'query_params' in config:
                config['query_params'] = self._replace_variables(config['query_params'])
        return config

    def _replace_variables(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Replace variable placeholders with actual values."""
        processed_params = {}
        for key, value in params.items():
            if isinstance(value, str) and value.startswith('{') and value.endswith('}'):
                var_name = value[1:-1]  # Remove { and }
                if var_name in self.variables:
                    processed_params[key] = self.variables[var_name]
                else:
                    # Keep original value if variable not found
                    processed_params[key] = value
            else:
                processed_params[key] = value
        return processed_params

    def validate_config(self, config: dict) -> dict:
        """Validate the configuration including date ranges."""
        if 'query_params' in config:
            params = config['query_params']
            # Get current values from variables
            from_date = self.variables.get('from_date')
            to_date = self.variables.get('to_date')
            
            if from_date and to_date:
                # Validate and adjust dates
                from_date, to_date = validate_and_adjust_date_range(from_date, to_date)
                # Update variables with validated dates
                self.variables.update({
                    'from_date': from_date,
                    'to_date': to_date
                })
                # Update config params
                params['issueDateFrom'] = from_date
                params['issueDateTo'] = to_date
                
        return config

    def get_variable(self, name: str) -> Any:
        """Get a variable value by name."""
        return self.variables.get(name)

    def update_variable(self, name: str, value: Any):
        """Update a variable value."""
        self.variables[name] = value
        
    def get_all_variables(self) -> Dict[str, Any]:
        """Get all variables."""
        return self.variables.copy() 