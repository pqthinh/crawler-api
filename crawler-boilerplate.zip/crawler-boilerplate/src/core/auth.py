import json
import time
import logging
from typing import Dict, Any, Optional
import requests
from pydantic import BaseModel
from enum import Enum

logger = logging.getLogger(__name__)

class AuthType(str, Enum):
    BASIC = "basic"
    BEARER = "bearer"
    OAUTH2 = "oauth2"
    API_KEY = "api_key"
    CUSTOM = "custom"

class AuthConfig(BaseModel):
    type: AuthType
    url: Optional[str] = None
    method: str = "POST"
    headers: Dict[str, str] = {}
    body: Optional[Dict[str, Any]] = None
    token_field: str = "access_token"
    token_type: str = "Bearer"
    expires_in_field: Optional[str] = "expires_in"
    token_path: Optional[str] = None  # For nested token in response
    cache_key: Optional[str] = None
    cache_ttl: Optional[int] = None  # Time to live in seconds

class AuthHandler:
    def __init__(self, config: AuthConfig):
        self.config = config
        self._token_cache: Dict[str, Dict[str, Any]] = {}
        self.session = requests.Session()
        if config.headers:
            self.session.headers.update(config.headers)

    def _get_cached_token(self) -> Optional[str]:
        """Get token from cache if it's still valid."""
        if not self.config.cache_key:
            return None

        cached = self._token_cache.get(self.config.cache_key)
        if not cached:
            return None

        # Check if token is expired
        if self.config.cache_ttl and time.time() > cached['expires_at']:
            return None

        return cached['token']

    def _cache_token(self, token: str, expires_in: Optional[int] = None):
        """Cache the token with expiration."""
        if not self.config.cache_key:
            return

        expires_at = None
        if expires_in:
            expires_at = time.time() + expires_in
        elif self.config.cache_ttl:
            expires_at = time.time() + self.config.cache_ttl

        self._token_cache[self.config.cache_key] = {
            'token': token,
            'expires_at': expires_at
        }

    def _extract_token(self, response: Dict[str, Any]) -> str:
        """Extract token from response based on configuration."""
        if self.config.token_path:
            # Handle nested token path (e.g., "data.token")
            current = response
            for key in self.config.token_path.split('.'):
                current = current.get(key, {})
            return str(current)
        return str(response.get(self.config.token_field, ''))

    def _extract_expires_in(self, response: Dict[str, Any]) -> Optional[int]:
        """Extract expiration time from response."""
        if not self.config.expires_in_field:
            return None
        return response.get(self.config.expires_in_field)

    def get_token(self) -> str:
        """Get authentication token, using cache if available."""
        # Try to get from cache first
        cached_token = self._get_cached_token()
        if cached_token:
            return cached_token

        try:
            if self.config.type == AuthType.BASIC:
                # Basic auth is handled by requests.Session
                return ""

            elif self.config.type == AuthType.BEARER:
                # For Bearer token, we need to make a request
                response = self.session.request(
                    method=self.config.method,
                    url=self.config.url,
                    json=self.config.body
                )
                response.raise_for_status()
                data = response.json()
                token = self._extract_token(data)
                expires_in = self._extract_expires_in(data)
                self._cache_token(token, expires_in)
                return token

            elif self.config.type == AuthType.OAUTH2:
                # OAuth2 flow
                response = self.session.request(
                    method=self.config.method,
                    url=self.config.url,
                    data=self.config.body if self.config.headers.get('Content-Type') == 'application/x-www-form-urlencoded' else None,
                    json=self.config.body if self.config.headers.get('Content-Type') != 'application/x-www-form-urlencoded' else None
                )
                response.raise_for_status()
                data = response.json()
                token = self._extract_token(data)
                expires_in = self._extract_expires_in(data)
                self._cache_token(token, expires_in)
                return token

            elif self.config.type == AuthType.API_KEY:
                # API Key is typically in headers or query params
                return self.config.headers.get('X-API-Key', '')

            elif self.config.type == AuthType.CUSTOM:
                # Custom authentication flow
                response = self.session.request(
                    method=self.config.method,
                    url=self.config.url,
                    json=self.config.body
                )
                response.raise_for_status()
                data = response.json()
                token = self._extract_token(data)
                expires_in = self._extract_expires_in(data)
                self._cache_token(token, expires_in)
                return token

            else:
                raise ValueError(f"Unsupported authentication type: {self.config.type}")

        except Exception as e:
            logger.error(f"Error getting authentication token: {str(e)}")
            raise

    def get_auth_headers(self) -> Dict[str, str]:
        """Get authentication headers based on the token."""
        token = self.get_token()
        if not token:
            return {}

        if self.config.type == AuthType.BASIC:
            return {}  # Basic auth is handled by requests.Session

        elif self.config.type in [AuthType.BEARER, AuthType.OAUTH2]:
            return {'Authorization': f"{self.config.token_type} {token}"}

        elif self.config.type == AuthType.API_KEY:
            return {'X-API-Key': token}

        elif self.config.type == AuthType.CUSTOM:
            return {'Authorization': f"{self.config.token_type} {token}"}

        return {} 