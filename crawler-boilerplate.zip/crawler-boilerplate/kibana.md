Để sử dụng Kibana dashboard:
Truy cập Kibana tại http://localhost:5601
Tạo các dashboard với các visualization:
Job Status Timeline
Error Distribution
Processing Statistics
Retry Analysis
Tạo các alert:
Khi tỷ lệ lỗi vượt ngưỡng
Khi job chạy quá lâu
Khi có nhiều retry
Tạo các report:
Daily/Weekly/Monthly statistics
Error analysis
Performance metrics
Bạn có thể truy vấn dữ liệu thông qua Elasticsearch API:
# Lấy danh sách job lỗi
failed_jobs = job_monitor.get_failed_jobs(
    api_id="example_api",
    start_time="2024-03-01T00:00:00Z",
    end_time="2024-03-02T00:00:00Z"
)

# Lấy thống kê lỗi
error_stats = job_monitor.get_error_stats(
    api_id="example_api",
    start_time="2024-03-01T00:00:00Z",
    end_time="2024-03-02T00:00:00Z"
)




Phát hiện lỗi:
Sử dụng các pattern để nhận diện lỗi block IP (403, 429, "IP blocked", etc.)
Nhận diện lỗi tạm khóa tài khoản (401, "account suspended", etc.)
Phân tích status code và nội dung lỗi
Xử lý thông minh:
Block IP:
Thời gian chờ: 1 giờ (có thể tăng theo số lần retry)
Số lần retry tối đa: 3 lần
Exponential backoff: thời gian chờ tăng gấp đôi mỗi lần retry
Tạm khóa tài khoản:
Thời gian chờ: 24 giờ
Số lần retry tối đa: 2 lần
Ghi log chi tiết để theo dõi
Rate limit:
Thời gian chờ: 10 phút
Số lần retry tối đa: 5 lần
Tăng thời gian chờ theo số lần retry
Monitoring và Alert:
Ghi log chi tiết vào Elasticsearch
Phân loại lỗi theo type (IP_BLOCK, ACCOUNT_SUSPENDED, RATE_LIMIT)
Theo dõi số lần retry và thời gian chờ
Có thể tạo alert khi phát hiện nhiều lỗi block IP hoặc tạm khóa tài khoản
Dashboard trong Kibana:
Biểu đồ phân bố các loại lỗi
Thống kê thời gian chờ trung bình
Danh sách các job bị block/tạm khóa
Alert khi có nhiều lỗi trong thời gian ngắn
Bạn có thể theo dõi tình trạng các job thông qua các API sau:
# Lấy danh sách job bị block IP
blocked_jobs = job_monitor.get_failed_jobs(
    api_id="example_api",
    error_type="ip_block"
)

# Lấy thống kê lỗi theo loại
error_stats = job_monitor.get_error_stats(
    api_id="example_api",
    start_time="2024-03-01T00:00:00Z",
    end_time="2024-03-02T00:00:00Z"
)